const searchBar = document.getElementById('search-bar');
const searchResults = document.getElementById('search-results');
const musicData = [
  {
    title: 'mustafa',
    artist: 'A.R.Rahaman',
    genre: 'friends',
    url: 'mustafa.mp3'
  },
  {
    title: 'yaar enna sonnalum',
    artist: 'Antony daasan',
    genre: 'Family',
    url: 'yaarennasonnalum.mp3'
  },
  {
    title: 'ennodu nee irunthal',
    artist: 'sid sriram',
    genre: 'love',
    url: 'song3.mp3'
  },
  {
    title: 'pallikudathula',
    artist: 'Hippop tamizha',
    genre: 'friends',
    url: 'natpey thunai.mp3'
  },
  {
    title: 'pachai kiligal',
    artist: 'A.R.rahaman',
    genre: 'Family',
    url: 'pachai kilikal.mp3'
  },
  {
    title: 'sonthamulla vazhka',
    artist: 'siddhu kumar',
    genre: 'Family',
    url: 'soontamulla vazha.mp3'
  },
  {
    title: 'yaele yaele dosthuda',
    artist: 'Harrish jayaraj',
    genre: 'Friends',
    url: 'yaele yaelae dosthuda.mp3'
  },
  {
    title: 'Muthal nee mudivum nee',
    artist: 'Sid sriram',
    genre: 'love',
    url: 'muthalnee.mp3'
  }
];


// Function to search for music
function searchMusic(query) {
  const results = musicData.filter(song => {
    return song.title.toLowerCase().includes(query.toLowerCase()) ||
           song.artist.toLowerCase().includes(query.toLowerCase()) ||
           song.genre.toLowerCase().includes(query.toLowerCase());
  });

  // Display search results
  searchResults.innerHTML = '';
  results.forEach(song => {
    const li = document.createElement('li');
    li.textContent = `${song.title} by ${song.artist} (${song.genre})`;
    searchResults.appendChild(li);
  });
}

// Event listener for search bar
searchBar.addEventListener('input', () => {
  const query = searchBar.value.trim();
  if (query) {
    searchMusic(query);
  } else {
    searchResults.innerHTML = '';
  }
});
